from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchaudio
import torchaudio.transforms as T


# =========================
# 需要修改的路径
# =========================

MODEL_PATH = Path(r"D:/desktop/Bird_Audio/Output/best_bird_cnn.pt")

# 要预测的单个音频
AUDIO_PATH = Path(r"D:/desktop/Bird_Audio/val/test.wav")

# 输出前几个最可能类别
TOP_K = 5


# =========================
# 必须和训练时的模型结构一致
# =========================

class BirdCNN(nn.Module):
    def __init__(self, num_classes):
        super().__init__()

        self.features = nn.Sequential(
            nn.Conv2d(1, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(2),

            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(2),

            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.MaxPool2d(2),

            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(),

            nn.AdaptiveAvgPool2d((1, 1))
        )

        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Dropout(0.3),
            nn.Linear(256, num_classes)
        )

    def forward(self, x):
        x = self.features(x)
        x = self.classifier(x)
        return x


def load_audio(audio_path, target_sr):
    waveform, sr = torchaudio.load(str(audio_path))

    # 转单声道
    if waveform.shape[0] > 1:
        waveform = waveform.mean(dim=0, keepdim=True)

    # 重采样
    if sr != target_sr:
        waveform = torchaudio.functional.resample(
            waveform,
            orig_freq=sr,
            new_freq=target_sr
        )

    return waveform


def split_audio_into_segments(waveform, num_samples):
    """
    如果音频比训练长度短：补零。
    如果音频比训练长度长：切成多个片段，分别预测，再平均结果。
    """
    total_samples = waveform.shape[1]

    if total_samples <= num_samples:
        pad_length = num_samples - total_samples
        waveform = F.pad(waveform, (0, pad_length))
        return [waveform]

    segments = []

    # 50% 重叠滑窗
    step = num_samples // 2

    start = 0
    while start + num_samples <= total_samples:
        segment = waveform[:, start:start + num_samples]
        segments.append(segment)
        start += step

    # 保证最后一段也被使用
    last_segment = waveform[:, -num_samples:]
    segments.append(last_segment)

    return segments


def waveform_to_mel(
    waveform,
    mel_transform,
    db_transform
):
    mel = mel_transform(waveform)
    mel_db = db_transform(mel)

    # 和训练时一致：单样本标准化
    mel_db = (mel_db - mel_db.mean()) / (mel_db.std() + 1e-6)

    return mel_db


def predict_audio(model, audio_path, checkpoint, device, top_k=5):
    class_names = checkpoint["class_names"]

    sample_rate = checkpoint["sample_rate"]
    duration = checkpoint["duration"]
    n_fft = checkpoint["n_fft"]
    hop_length = checkpoint["hop_length"]
    n_mels = checkpoint["n_mels"]
    fmin = checkpoint["fmin"]
    fmax = checkpoint["fmax"]
    top_db = checkpoint["top_db"]

    num_samples = int(sample_rate * duration)

    mel_transform = T.MelSpectrogram(
        sample_rate=sample_rate,
        n_fft=n_fft,
        win_length=n_fft,
        hop_length=hop_length,
        f_min=fmin,
        f_max=fmax,
        n_mels=n_mels,
        power=2.0
    ).to(device)

    db_transform = T.AmplitudeToDB(
        stype="power",
        top_db=top_db
    ).to(device)

    waveform = load_audio(audio_path, sample_rate)
    segments = split_audio_into_segments(waveform, num_samples)

    model.eval()

    all_probs = []

    with torch.no_grad():
        for segment in segments:
            segment = segment.to(device)

            mel_db = waveform_to_mel(
                segment,
                mel_transform,
                db_transform
            )

            # [1, n_mels, time] -> [batch, channel, n_mels, time]
            mel_db = mel_db.unsqueeze(0)

            logits = model(mel_db)
            probs = torch.softmax(logits, dim=1)

            all_probs.append(probs)

    # 多个片段的结果取平均
    mean_probs = torch.mean(torch.cat(all_probs, dim=0), dim=0)

    top_probs, top_indices = torch.topk(
        mean_probs,
        k=min(top_k, len(class_names))
    )

    results = []

    for prob, idx in zip(top_probs.cpu().tolist(), top_indices.cpu().tolist()):
        results.append({
            "label": class_names[idx],
            "probability": prob
        })

    return results


def main():
    if not MODEL_PATH.exists():
        raise FileNotFoundError(f"找不到模型文件: {MODEL_PATH}")

    if not AUDIO_PATH.exists():
        raise FileNotFoundError(f"找不到音频文件: {AUDIO_PATH}")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"使用设备: {device}")

    checkpoint = torch.load(MODEL_PATH, map_location=device)

    class_names = checkpoint["class_names"]

    model = BirdCNN(num_classes=len(class_names)).to(device)
    model.load_state_dict(checkpoint["model_state_dict"])

    results = predict_audio(
        model=model,
        audio_path=AUDIO_PATH,
        checkpoint=checkpoint,
        device=device,
        top_k=TOP_K
    )

    print(f"\n预测音频: {AUDIO_PATH}")
    print("预测结果:")

    for i, item in enumerate(results, start=1):
        label = item["label"]
        prob = item["probability"]

        print(f"{i}. {label}: {prob:.4f}")


if __name__ == "__main__":
    main()