from pathlib import Path
import csv
import torch
import torchaudio


# =========================
# 需要你修改的路径
# =========================

DATA_DIR = Path(r"D:/desktop/Bird_Audio/42个鸟类物种")

# 日志文件
LOG_CSV = Path(r"D:/desktop/Bird_Audio/audio_clean_convert_log.csv")


# =========================
# 参数设置
# =========================

AUDIO_EXTENSIONS = {
    ".wav", ".mp3", ".flac", ".ogg", ".m4a", ".aac"
}

# 先设置 True，只检查不删除、不转换
# 确认日志没问题后，再改成 False
DRY_RUN = False

# 是否删除损坏音频
DELETE_BAD_FILES = True

# 非 wav 转换成功后，是否删除原始文件
# 建议 True，避免训练时重复读到同一条音频
DELETE_ORIGINAL_AFTER_CONVERT = True

# 是否统一转单声道
FORCE_MONO = True

# 是否统一采样率
# 鸟鸣分类建议 32000
# 如果想保留原采样率，改成 None
TARGET_SR = 32000

# 如果目标 wav 已经存在，是否跳过转换
SKIP_IF_WAV_EXISTS = True


def safe_load_audio(audio_path):
    """
    尝试读取音频。
    成功返回 waveform, sr。
    失败抛出异常。
    """
    waveform, sr = torchaudio.load(str(audio_path))

    if waveform.numel() == 0:
        raise RuntimeError("空音频文件")

    if not torch.isfinite(waveform).all():
        raise RuntimeError("音频中存在 NaN 或 Inf")

    return waveform, sr


def process_waveform(waveform, sr):
    """
    转单声道、重采样、限制幅度。
    """
    if FORCE_MONO and waveform.shape[0] > 1:
        waveform = waveform.mean(dim=0, keepdim=True)

    if TARGET_SR is not None and sr != TARGET_SR:
        waveform = torchaudio.functional.resample(
            waveform,
            orig_freq=sr,
            new_freq=TARGET_SR
        )
        sr = TARGET_SR

    waveform = waveform.clamp(-1.0, 1.0)

    return waveform, sr


def make_wav_output_path(audio_path):
    """
    把原文件路径改成 .wav。
    例如:
    721997.mp3 -> 721997.wav
    """
    return audio_path.with_suffix(".wav")


def write_log_header(log_path):
    log_path.parent.mkdir(parents=True, exist_ok=True)

    with open(log_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "path",
                "status",
                "action",
                "output_path",
                "error"
            ]
        )
        writer.writeheader()


def append_log(log_path, row):
    with open(log_path, "a", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "path",
                "status",
                "action",
                "output_path",
                "error"
            ]
        )
        writer.writerow(row)


def main():
    if not DATA_DIR.exists():
        raise FileNotFoundError(f"找不到数据集目录: {DATA_DIR}")

    write_log_header(LOG_CSV)

    audio_files = [
        p for p in DATA_DIR.rglob("*")
        if p.is_file() and p.suffix.lower() in AUDIO_EXTENSIONS
    ]

    print(f"数据集目录: {DATA_DIR}")
    print(f"找到音频文件数量: {len(audio_files)}")
    print(f"DRY_RUN: {DRY_RUN}")
    print("-" * 80)

    total_ok = 0
    total_bad = 0
    total_converted = 0
    total_deleted_bad = 0
    total_deleted_original = 0
    total_skipped = 0

    for i, audio_path in enumerate(audio_files, start=1):
        suffix = audio_path.suffix.lower()

        print(f"[{i}/{len(audio_files)}] 检查: {audio_path}")

        try:
            waveform, sr = safe_load_audio(audio_path)

        except Exception as e:
            total_bad += 1

            print(f"  损坏或无法读取: {e}")

            action = "bad_file_detected"

            if DELETE_BAD_FILES:
                action = "delete_bad_file"

                if not DRY_RUN:
                    try:
                        audio_path.unlink()
                        total_deleted_bad += 1
                        print("  已删除损坏文件")
                    except Exception as delete_error:
                        print(f"  删除失败: {delete_error}")

                        append_log(LOG_CSV, {
                            "path": str(audio_path),
                            "status": "bad",
                            "action": "delete_failed",
                            "output_path": "",
                            "error": str(delete_error)
                        })
                        continue

            append_log(LOG_CSV, {
                "path": str(audio_path),
                "status": "bad",
                "action": action,
                "output_path": "",
                "error": str(e)
            })

            continue

        # 到这里说明音频能读
        total_ok += 1

        # wav 文件只检查，不转换
        if suffix == ".wav":
            print("  正常 wav，保留")

            append_log(LOG_CSV, {
                "path": str(audio_path),
                "status": "ok",
                "action": "keep_wav",
                "output_path": str(audio_path),
                "error": ""
            })

            continue

        # 非 wav 文件转换
        output_path = make_wav_output_path(audio_path)

        if output_path.exists() and SKIP_IF_WAV_EXISTS:
            print(f"  目标 wav 已存在，跳过转换: {output_path}")

            total_skipped += 1

            append_log(LOG_CSV, {
                "path": str(audio_path),
                "status": "ok",
                "action": "skip_convert_wav_exists",
                "output_path": str(output_path),
                "error": ""
            })

            continue

        try:
            waveform, sr = process_waveform(waveform, sr)

            if not DRY_RUN:
                torchaudio.save(
                    str(output_path),
                    waveform,
                    sr
                )

            total_converted += 1

            print(f"  已转换为 wav: {output_path}")

            # 转换成功后删除原始非 wav
            if DELETE_ORIGINAL_AFTER_CONVERT:
                if not DRY_RUN:
                    audio_path.unlink()

                total_deleted_original += 1
                print("  已删除原始非 wav 文件")

            append_log(LOG_CSV, {
                "path": str(audio_path),
                "status": "ok",
                "action": "converted_to_wav",
                "output_path": str(output_path),
                "error": ""
            })

        except Exception as e:
            print(f"  转换失败: {e}")

            append_log(LOG_CSV, {
                "path": str(audio_path),
                "status": "ok_but_convert_failed",
                "action": "convert_failed",
                "output_path": str(output_path),
                "error": str(e)
            })

    print("-" * 80)
    print("处理完成")
    print(f"可读取音频数量: {total_ok}")
    print(f"损坏音频数量: {total_bad}")
    print(f"已转换 wav 数量: {total_converted}")
    print(f"已删除损坏文件数量: {total_deleted_bad}")
    print(f"已删除原始非 wav 数量: {total_deleted_original}")
    print(f"跳过转换数量: {total_skipped}")
    print(f"日志文件: {LOG_CSV}")

    if DRY_RUN:
        print("\n当前是 DRY_RUN=True，只做检查，不会真正删除或转换。")
        print("确认日志无误后，把 DRY_RUN 改成 False 再运行。")


if __name__ == "__main__":
    main()