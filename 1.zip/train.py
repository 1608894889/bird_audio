from ultralytics import YOLO
import os

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"


def train_yolov11(
    model_path="D:/desktop/yolo合集/yolov11-main/yolo11-MANet.yaml",
    data_path="F:/object_detect/AL/data.yml",
    epochs=300,
    imgsz=640,
    batch_size=16,
    lr0=0.01,
    lrf=0.01,
    cos_lr=True,
    warmup_epochs=5,
    warmup_momentum=0.937,
    warmup_bias_lr=0.1,
    cls=0.5,
    kobj=1.0,
    augment=False,
    mosaic=0.0,
    mixup=0.0,
    copy_paste=0.0,
    device="cuda",
):
    """
    YOLOv12 训练脚本（程序化形式）
    """

    # 初始化模型（可以加载官方预训练权重）
    model = YOLO(model_path)

    # 开始训练
    model.train(
        data=data_path,
        epochs=epochs,
        imgsz=imgsz,
        batch=batch_size,
        workers=0,
        # 学习率相关
        lr0=lr0,
        lrf=lrf,
        cos_lr=cos_lr,
        warmup_epochs=warmup_epochs,
        warmup_momentum=warmup_momentum,
        warmup_bias_lr=warmup_bias_lr,

        # 损失权重
        cls=cls,
        kobj=kobj,

        # 数据增强
        augment=augment,
        mosaic=mosaic,
        mixup=mixup,
        copy_paste=copy_paste,

        # 验证集
        val=True,

        # 其他参数
        patience=20,
        weight_decay=0.001,
        device=device,
        save=True,
        save_period=10,
        cache='disk',
        exist_ok=False,
        optimizer="auto",
        verbose=True,
        seed=0,
        deterministic=True,
        single_cls=False,
        rect=False,
        close_mosaic=0,

    )


if __name__ == "__main__":
    # 调用训练函数
    train_yolov11()
