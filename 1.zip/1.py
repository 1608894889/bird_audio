import numpy as np
import librosa
import matplotlib.pyplot as plt
from pathlib import Path


# =========================
# 路径
# =========================

INPUT_AUDIO = r"F:/pteroset数据集/测试/3.mp3"
OUTPUT_IMAGE = r"F:/pteroset数据集/测试/3.png"


# =========================
# 梅尔谱参数
# =========================

SR = 48000
N_FFT = 4096
HOP_LENGTH = 256
N_MELS = 256

FMIN = 500
FMAX = 18000

TOP_DB = 80


# =========================
# 输出图片参数
# =========================

PIXELS_PER_SECOND = 300
OUT_HEIGHT_PX = 420
DPI = 300

# 防止超长音频生成特别大的图片
MAX_WIDTH_PX = 30000


def audio_to_clean_mel_image(
    input_audio,
    output_image,
    sr=48000,
    n_fft=4096,
    hop_length=256,
    n_mels=256,
    fmin=500,
    fmax=18000,
    top_db=80,
    pixels_per_second=300,
    out_height_px=420,
    dpi=300,
    max_width_px=30000,
):
    input_audio = Path(input_audio)
    output_image = Path(output_image)

    if not input_audio.exists():
        raise FileNotFoundError(f"找不到音频文件: {input_audio}")

    output_image.parent.mkdir(parents=True, exist_ok=True)

    # 读取音频
    y, sr = librosa.load(input_audio, sr=sr, mono=True)

    duration = librosa.get_duration(y=y, sr=sr)

    print(f"音频采样率: {sr}")
    print(f"音频长度: {duration:.2f} 秒")

    # 根据音频时长计算图片宽度
    out_width_px = int(round(duration * pixels_per_second))

    # 避免图片宽度过小
    out_width_px = max(out_width_px, 1)

    # 避免超长音频生成过大的图片
    if out_width_px > max_width_px:
        print(f"警告：计算得到的图片宽度为 {out_width_px}px，超过上限 {max_width_px}px")
        print(f"已限制为 {max_width_px}px")
        out_width_px = max_width_px

    print(f"输出图片尺寸: {out_width_px} x {out_height_px}")

    # 归一化，避免整体能量太小
    if np.max(np.abs(y)) > 0:
        y = librosa.util.normalize(y)

    # 防止 fmax 超过奈奎斯特频率
    effective_fmax = min(fmax, sr / 2)

    if effective_fmax <= fmin:
        raise ValueError(
            f"频率范围不合法: fmin={fmin}, fmax={effective_fmax}, sr={sr}"
        )

    # 计算 Mel Spectrogram
    mel_spec = librosa.feature.melspectrogram(
        y=y,
        sr=sr,
        n_fft=n_fft,
        hop_length=hop_length,
        n_mels=n_mels,
        power=2.0,
        fmin=fmin,
        fmax=effective_fmax,
    )

    # 转 dB
    mel_spec_db = librosa.power_to_db(
        mel_spec,
        ref=np.max,
        top_db=top_db,
    )

    # 直接画矩阵，不画坐标轴、不画 colorbar
    fig = plt.figure(
        figsize=(out_width_px / dpi, out_height_px / dpi),
        dpi=dpi,
    )

    ax = fig.add_axes([0, 0, 1, 1])

    ax.imshow(
        mel_spec_db,
        origin="lower",
        aspect="auto",
        cmap="magma",
        vmin=-top_db,
        vmax=0,
        interpolation="nearest",
    )

    ax.axis("off")

    # 不使用 bbox_inches="tight"，避免改变最终像素尺寸
    plt.savefig(
        output_image,
        dpi=dpi,
        pad_inches=0,
    )

    plt.close(fig)

    print(f"Clean Mel spectrogram saved to: {output_image}")


if __name__ == "__main__":
    audio_to_clean_mel_image(
        input_audio=INPUT_AUDIO,
        output_image=OUTPUT_IMAGE,
        sr=SR,
        n_fft=N_FFT,
        hop_length=HOP_LENGTH,
        n_mels=N_MELS,
        fmin=FMIN,
        fmax=FMAX,
        top_db=TOP_DB,
        pixels_per_second=PIXELS_PER_SECOND,
        out_height_px=OUT_HEIGHT_PX,
        dpi=DPI,
        max_width_px=MAX_WIDTH_PX,
    )